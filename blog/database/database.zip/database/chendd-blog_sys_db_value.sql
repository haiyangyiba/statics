-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: chendd-blog
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sys_db_value`
--

DROP TABLE IF EXISTS `sys_db_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sys_db_value` (
  `id` bigint(20) NOT NULL COMMENT '主键ID',
  `key` varchar(64) DEFAULT NULL COMMENT '参数名',
  `value` varchar(2048) DEFAULT NULL COMMENT '参数值',
  `group` varchar(32) DEFAULT NULL COMMENT '参数组名',
  `remark` varchar(512) DEFAULT NULL COMMENT '参数备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统参数配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_db_value`
--

LOCK TABLES `sys_db_value` WRITE;
/*!40000 ALTER TABLE `sys_db_value` DISABLE KEYS */;
INSERT INTO `sys_db_value` VALUES (1,'client_ID','你的','third.login.weibo4j','sina微博登录'),(2,'client_SERCRET','你的','third.login.weibo4j','sina微博登录'),(3,'redirect_URI','http://www.chendd.cn:8888/v1/third-login/sinaCallback','third.login.weibo4j','sina微博登录'),(4,'baseURL','https://api.weibo.com/2/','third.login.weibo4j','sina微博登录'),(5,'accessTokenURL','https://api.weibo.com/oauth2/access_token','third.login.weibo4j','sina微博登录'),(6,'authorizeURL','https://api.weibo.com/oauth2/authorize','third.login.weibo4j','sina微博登录'),(7,'rmURL','https://rm.api.weibo.com/2/','third.login.weibo4j','sina微博登录'),(8,'jiajitao','http://www.jiajitao.cn','third.login.friends','来自jiajitao站点接入本站的第三方登录'),(9,'lishengle','http://www.lishengle.xyz','third.login.friends','来自lishengle站点接入本站的第三方登录'),(10,'appId','你的','third.login.baidu','baidu账号登录'),(11,'appSecretKey','你的','third.login.baidu','baidu账号登录'),(12,'callback','http://www.chendd.cn/third-login/baiduCallback','third.login.baidu','baidu账号登录'),(13,'userImage.prefix','http://tb.himg.baidu.com/sys/portraitn/item/','third.login.baidu','baidu账号登录'),(14,'client_id','你的','third.login.gitee','gitee账号登录，应用id'),(15,'redirect_uri','http://www.chendd.cn:8888/v1/third-login/giteeCallback','third.login.gitee','gitee账号登录，重定向地址'),(16,'authorizeURL','https://gitee.com','third.login.gitee','gitee账号登录，授权页面地址'),(17,'client_secret','你的','third.login.gitee','gitee账号登录，Client Secret'),(18,'client_id','你的','third.login.github','github账号登录，client_id'),(19,'client_secret','你的','third.login.github','github账号登录，Client Secret'),(20,'redirect_uri','http://www.chendd.cn:8888/v1/third-login/githubCallback','third.login.github','github账号登录，redirect_uri'),(22,'authorizeURL','https://github.com/login/oauth','third.login.github','github账号登录，授权页面地址'),(23,'userApiURL','https://api.github.com/user','third.login.github','github账号登录，URL地址跟路径'),(24,'rootPath','/app/BLOG_FILES/','system.file','系统上传文件存储根路径'),(1277962821295960066,'http.server.name','33','test','test1122'),(1284081247764647938,'傻逼','SX*','敏感字符过滤','S*逼替换为s*'),(1284081853938044930,'我操','WOC*','敏感字符过滤','我操替换为woc*'),(1284087507050336258,'他妈的','TMD*','敏感字符过滤','M*的替换为m*'),(1284088975899791361,'\"','＂','特殊字符过滤','英文双引号'),(1284090066959896577,'\'','＇','特殊字符过滤','英文单引号'),(1284090346883551233,'<','＜','特殊字符过滤','小于号'),(1284090490144198657,'>','＞','特殊字符过滤','大于号'),(1284455263008489473,'你妈的','NMD*','敏感字符过滤','你妈的'),(1359879356440137729,'chendd','http://www.chendd.cn/third-login/loginCallback','third.login.friends','localhost站点接入本站的第三方登录'),(1364187364359974913,'appId','你的','腾讯滑动验证码','接入腾讯的滑动式验证码接口参数，用于服务端的验证码验证'),(1364187686054703105,'secret','你的','腾讯滑动验证码','接入腾讯的滑动式验证码接口参数，用于服务端的验证码验证'),(1364187922118520834,'httpUrl','https://ssl.captcha.qq.com/ticket/verify','腾讯滑动验证码','接入腾讯的滑动式验证码接口参数，用于服务端的验证码验证'),(1395246903825920001,'appId','你的','third.login.alipay','支付宝账户登录'),(1395246903825920002,'redirectURI','http://www.chendd.cn:8888/v1/third-login/alipayCallback','third.login.alipay','支付宝账户登录'),(1395246903825920003,'authorizeURL','https://openauth.alipay.com/oauth2/publicAppAuthorize.htm','third.login.alipay','支付宝账户登录'),(1395246903825920004,'authAddress','https://openapi.alipay.com/gateway.do','third.login.alipay','支付宝账户登录'),(1395246903825920005,'appPrivateKey','你的','third.login.alipay','支付宝账户登录'),(1395246903825920006,'alipayPublicKey','你的','third.login.alipay','支付宝账户登录'),(1456981224936452098,'blog.createSiteTime','2015-07-17','博客参数','博客建站时间'),(1500701919302144001,'web首页','https://localhost/','shortcut.menu','快捷菜单：web首页地址'),(1500716092346105858,'swagger','/doc.html','shortcut.menu','快捷菜单：在线swagger地址'),(1502808681693593601,'app_ID','你的','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502808829085630465,'app_KEY','你的','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872194,'redirect_URI','https://www.chendd.cn/tencent-login/tencentCallback','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872195,'scope','get_user_info,add_topic,add_one_blog,add_album,upload_pic,list_album,add_share,check_page_fans,add_t,add_pic_t,del_t,get_repost_list,get_info,get_other_info,get_fanslist,get_idollist,add_idol,del_ido,get_tenpay_addr','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872196,'baseURL','https://graph.qq.com/','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872197,'getUserInfoURL','https://graph.qq.com/user/get_user_info','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872198,'accessTokenURL','https://graph.qq.com/oauth2.0/token','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872199,'authorizeURL','https://graph.qq.com/oauth2.0/authorize','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872200,'getOpenIDURL','https://graph.qq.com/oauth2.0/me','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872201,'addTopicURL','https://graph.qq.com/shuoshuo/add_topic','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872202,'addBlogURL','https://graph.qq.com/blog/add_one_blog','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872203,'addAlbumURL','https://graph.qq.com/photo/add_album','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872204,'uploadPicURL','https://graph.qq.com/photo/upload_pic','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872205,'listAlbumURL','https://graph.qq.com/photo/list_album','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872206,'addShareURL','https://graph.qq.com/share/add_share','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872207,'checkPageFansURL','https://graph.qq.com/user/check_page_fans','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872208,'addTURL','https://graph.qq.com/t/add_t','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872209,'addPicTURL','https://graph.qq.com/t/add_pic_t','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872210,'delTURL','https://graph.qq.com/t/del_t','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872211,'getWeiboUserInfoURL','https://graph.qq.com/user/get_info','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872212,'getWeiboOtherUserInfoURL','https://graph.qq.com/user/get_other_info','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872213,'getFansListURL','https://graph.qq.com/relation/get_fanslist','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872214,'getIdolsListURL','https://graph.qq.com/relation/get_idollist','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872215,'addIdolURL','https://graph.qq.com/relation/add_idol','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872216,'delIdolURL','https://graph.qq.com/relation/del_idol','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872217,'getTenpayAddrURL','https://graph.qq.com/cft_info/get_tenpay_addr','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872218,'getRepostListURL','https://graph.qq.com/t/get_repost_list','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1502809129636872219,'version','2.0.0.0','third.login.tencentQQ','第三方登录腾讯QQ参数设置'),(1517136827309928450,'mail.remind.title','系统消息定时检查-有新提醒','mail.remind','系统消息定时检查-有新提醒'),(1517137003185483778,'mail.remind.to','你的','mail.remind','接收系统邮件提醒的邮箱'),(1517137003185486666,'mail.remind.bcc','你的','mail.remind','接收回复给用户邮件提醒密送的邮箱');
/*!40000 ALTER TABLE `sys_db_value` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-05 13:55:10
