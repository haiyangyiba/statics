-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: chendd-blog
-- ------------------------------------------------------
-- Server version	5.7.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sys_operationlog_module`
--

DROP TABLE IF EXISTS `sys_operationlog_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sys_operationlog_module` (
  `moduleId` varchar(128) NOT NULL COMMENT '模块ID',
  `moduleName` varchar(256) DEFAULT NULL COMMENT '模块名称',
  `functionName` varchar(256) DEFAULT NULL COMMENT '功能名称',
  PRIMARY KEY (`moduleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统操作日志功能模块定义';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_operationlog_module`
--

LOCK TABLES `sys_operationlog_module` WRITE;
/*!40000 ALTER TABLE `sys_operationlog_module` DISABLE KEYS */;
INSERT INTO `sys_operationlog_module` VALUES ('ArticleContentServiceImpl.saveArticleContent','博客管理','文章管理-内容编辑'),('ArticleManageServiceImpl.queryArticleManagePage','博客管理','文章管理-列表查询'),('ArticleManageServiceImpl.removeArticle','博客管理','文章管理-数据删除'),('ArticleManageServiceImpl.saveArticle','博客管理','文章管理-新增或修改'),('ArticlePropertyServiceImpl.changeProperty','博客管理','文章管理-属性编辑'),('ArticlePropertyServiceImpl.removeArticleCover','博客管理','文章管理-封面删除'),('ArticlePropertyServiceImpl.uploadArticleCover','博客管理','文章管理-封面设置'),('CacheManageServiceImpl.queryCacheByName','运维管理','缓存管理-单个缓存列表查询'),('CacheManageServiceImpl.queryCachesList','运维管理','缓存管理-列表查询'),('CacheManageServiceImpl.removeAllCache','运维管理','缓存管理-全部删除'),('CacheManageServiceImpl.removeCacheElement','运维管理','缓存管理-缓存数据删除'),('CacheManageServiceImpl.removeCacheElementStartWith','运维管理','缓存管理-选定缓存的元素前缀删除'),('CacheManageServiceImpl.removeSelectedCache','运维管理','缓存管理-选定缓存删除'),('FriendsLinkServiceImpl.queryFriendsLink','博客管理','友链管理-列表查询'),('FriendsLinkServiceImpl.removeFriendsLink','博客管理','友链管理-删除'),('FriendsLinkServiceImpl.saveFriendsLink','博客管理','友链管理-新增或修改'),('OnlineQueryServiceImpl.executeQuery','运维管理','在线查询-SQL查询'),('QuartzJobExecuteServiceImpl.getResultById','系统管理','任务历史-明细查看'),('QuartzJobExecuteServiceImpl.queryQuartzJobExecuteList','任务管理','定时任务-访问统计'),('QuartzManageServiceImpl.operationQuartz','系统管理','任务管理-任务操作'),('QuartzManageServiceImpl.queryQuartzList','系统管理','任务管理-列表查询'),('QuartzManageServiceImpl.removeQuartz','系统管理','参数管理-任务删除'),('QuartzManageServiceImpl.saveQuartz','系统管理','参数管理-新增或修改'),('SysCommentServiceImpl.getCommentById','博客管理','留言管理-查看留言内容'),('SysCommentServiceImpl.querySysCommentManagePage','博客管理','留言管理-列表查询'),('SysDbValueServiceImpl.removeSysDbValue','系统管理','参数管理-同步更新'),('SysDbValueServiceImpl.saveSysDbValue','系统管理','参数管理-新增或修改'),('SysDbValueServiceImpl.selectAll','系统管理','参数管理-列表查询'),('SysInfoContentService.queryInfoContentList','系统管理','内容管理-列表查询'),('SysInfoContentService.removeInfoContent','系统管理','内容管理-数据删除'),('SysInfoContentService.saveSysInfoContent','系统管理','内容管理-新增或修改'),('SysInfoContentService.viewSysInfoContent','系统管理','内容管理-查看明细'),('SysMenuServiceImpl.queryAll','系统管理','菜单管理-列表查询'),('SysMenuServiceImpl.removeMenus','系统管理','菜单管理-删除'),('SysMenuServiceImpl.saveSysMenu','系统管理','菜单管理-新增或修改'),('SysRequestDetailServiceImpl.queryAccessManagePage','运维管理','访问管理'),('SysRequestDetailServiceImpl.queryAccessRequestManagePage','运维管理','访问明细'),('SysRequestDetailServiceImpl.transferRequestDetail','系统管理','定时任务-定时统计'),('SysRoleMenuServiceImpl.loginUser','系统管理','登录-用户登录'),('SysRoleMenuServiceImpl.logoutUser','系统管理','登录-用户退出'),('SysRoleMenuServiceImpl.saveRoleMenu','系统管理','角色管理-编辑角色菜单'),('SysRoleServiceImpl.queryRoles','系统管理','角色管理-列表查询'),('SysRoleServiceImpl.removeRoles','系统管理','角色管理-删除'),('SysRoleServiceImpl.saveSysRole','系统管理','角色管理-新增或修改'),('SysUserRoleServiceImpl.saveBatch','系统管理','用户管理-编辑角色'),('SysUserServiceImpl.editUser','系统管理','用户管理-新增或修改'),('SysUserServiceImpl.editUserStatus','系统管理','用户管理-编辑状态'),('SysUserServiceImpl.getUserInfoViewById','系统管理','用户管理-查看用户'),('SysUserServiceImpl.querySysUserPage','系统管理','用户管理-列表查询'),('SysUserServiceImpl.resetPassword','系统管理','用户管理-密码重置'),('SysUserServiceImpl.saveUser','系统管理','用户管理-新增或修改'),('TagArticleManageService.queryTagsArticlePage','博客管理','标签管理-查询标签文章'),('TagArticleManageService.saveTagsArticle','博客管理','标签管理-设置标签文章'),('TagManageServiceImpl.queryTagManagePage','博客管理','标签管理-列表查询'),('TagManageServiceImpl.removeTag','博客管理','标签管理-删除'),('TagManageServiceImpl.saveTag','博客管理','标签管理-新增或修改');
/*!40000 ALTER TABLE `sys_operationlog_module` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-05 13:55:09
